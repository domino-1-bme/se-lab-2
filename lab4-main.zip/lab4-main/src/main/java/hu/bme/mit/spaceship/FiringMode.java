package hu.bme.mit.spaceship;

/**
* Weapon firing mode enumeration
*
*/
public enum FiringMode {
  SINGLE, ALL
}
